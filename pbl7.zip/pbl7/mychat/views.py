from django.shortcuts import render
from django.shortcuts import redirect
from django.views.generic import View
from . import models
from django.http import HttpResponse
import urllib.parse
from .form import WriteForm
from django.urls import reverse
# Create your views here.
def startView(request):
    template_file="mychat/start.html"

    response=render(request,template_file)
    return response
def mainView(request):
    template_file_1="mychat/main_1.html"
    template_file_2="mychat/main_2.html"
    back_file="mychat/start.html"
    error_message=[]

    #[1] クッキー情報(後述)からユーザ名(USERをキー名とする)を取得する。 
    cookie_value = request.COOKIES.get('USER') 
    if cookie_value is not None:
        value = urllib.parse.unquote(cookie_value)
    else:
        value=None
    options={}
    #[2] ユーザ名を取得できた場合は、以下を行う。 
    if value is not None:
    #[2](1) データベースからそのユーザ名と完全一致するユーザ情報を取得する。 
        user = models.User.objects.filter(name__exact=value).first()
    #[2](2)ユーザ情報のログイン状態がログイン中(True)ならば認証処理は行わずにメイン画 
    #面に遷移する。（遷移パターンA） 
        if user is not None and user.islogin:
            roomlist=models.Room.objects.all()
            if user.group_id == "1":
                template_file = template_file_1  # カスタマー側
            else:
                template_file = template_file_2  # サーバー側

            options={
                'roomlist':roomlist,
                'user':user
            }
            return render(request,template_file,options)
    #[2](3)ユーザ情報のログイン状態がログイン中でない(False)場合、クッキーからユーザ名 
    #を削除(後述)してから、ログイン画面に遷移する（遷移パターンB） 
        else:
            response = render(request, back_file, options) 
            response.delete_cookie('USER')   # key は削除したいキー名が入る 
            return response 
    #[3] フォームのデータとしてユーザ名、パスワード、ログインフラグを取得し、内部変数user、 
    #password、login にそれぞれ代入する。ログインフラグが取得できなかった場合はNoneでは 
    #なく"off"を値として代入する。 
    if "name" in request.POST:
        name=request.POST.get("name")
    else:
        name = None
    if "password" in request.POST:
        password=request.POST.get("password")
    else:
        password = None
    if "login" in request.POST:
        login=request.POST.get("login")
    else:
        login = 'off' 

    #[4] ログインフラグが "on"ではない 時は、ログイン画面に遷移する。（遷移パターンC） 
    if login != 'on':
        error_message.append("ログインフラグが有効ではありません")
        options = {"error_message":error_message}
        return render(request,back_file,options)

    #[5] ユーザ名が取得できない場合は「ユーザ名が入力されていません」というエラーメッセージ 
    #を用意する。 
    if name is None or name=='':
        error_message.append("ユーザー名が入力されていません")
    #[6] パスワードが取得できない場合は「パスワードが入力されていません」というエラーメッセージを用意する。
    if password is None or password=='':
        error_message.append("パスワードが入力されていません")
    #[7] [5][6]で入力エラーのメッセージが１つでも用意されたならば、それをテンプレートに渡す 
    #（遷移パターンD） 
    if len(error_message) > 0:
        errors = {'error_message':error_message}
        return render(request,back_file,errors)

    #[8] データベースから「ユーザ名」と「パスワード」の両方が完全一致するユーザ情報を取得する。
    user_info=models.User.objects.filter(name__exact=name,password__exact=password).first()
    #[9] 一致するユーザ情報が取得できなかった場合は、「ユーザ名、パスワードが一致しません」と#
    #いうエラーメッセージを用意し、ログイン画面に遷移し、それをメッセージ表示エリアに赤 
    #字で表示する。（遷移パターンE） 
    if user_info is None:
        error_message.append("ユーザー名、パスワードが一致しません")
        errors={'error_message':error_message}
        return render(request,back_file,errors)
    #[10] 一致するユーザ情報が取得できた場合には、そのユーザ情報のログイン状態をTrueにして、データベースを更新する。 
    user_info.islogin = True
    user_info.save()

    roomlist=models.Room.objects.all()
    options={
        'roomlist':roomlist,
        "user": user_info
    }
    #[11] 更新後、ユーザ名(USERをキー名とする)をクッキー情報として設定しつつメイン画面に遷移する。（遷移パターンF） 
    response = render(request, template_file_1 if user_info.group_id == "1" else template_file_2, options) 
    response.set_cookie('USER', urllib.parse.quote(str(name)))  # key, value は保存したいキー名と値 
    return response 
def createUser(request):
    template_file="mychat/createuser.html"
    options={}
    return render(request,template_file,options)
def addUser(request):  

    template_file="mychat/adduser.html"
    error_message=[]
    message=[]

    if "name" in request.POST:
        name=request.POST.get("name")
    if "password" in request.POST:
        password=request.POST.get("password")
    if "group_id" in request.POST:
        group_id=request.POST.get('group_id')

    if name is None or name == '':
        error_message.append("名前が入力されていません")
    if password is None or password == '':
        error_message.append("パスワードが入力されていません")
    if not group_id:
        error_message.append("グループを選択してください")
    else:
        try:
            group_id = int(group_id)
            if group_id not in [1, 2]:  # 有効なグループIDを指定
                error_message.append("無効なグループが選択されました")
        except ValueError:
            error_message.append("無効なグループが選択されました")

    #[4]
    if len(error_message)==0:
        #[4](1)
        #[4](2)
        if models.User.objects.filter(name__exact=name).first():
            error_message.append("すでにそのユーザーは存在します")
        #[4](3)
        else:
            user=models.User.objects.create(
            name=name,
            password=password,
            group_id=group_id
            )
            user.save()
            message.append("ユーザー"+name+"を登録しました")

    #[5]    
    options = {
        'error_message':error_message,
        'message':message
        }
    return render(request, template_file, options)
def logout(request):
    value = request.COOKIES.get('USER')
    if value is not None:
        user = models.User.objects.filter(name=value).first()
        if user is not None:
            user.islogin=False
            user.save()
    return redirect('/mychat')

def createRoom(request):
    template_file="mychat/createroom.html"
    options={

    }
    return render(request,template_file,options)

def addRoom(request):
    template_file="mychat/addroom.html"
    message=[]
    error_message=[]
    if "name" in request.POST:
        name=request.POST.get("name")
    #[2]
    if name is None or name == '':
        error_message.append("掲示板名が入力されていません")

    #[3]
    else:
        if models.Room.objects.filter(name__exact=name).exists():
            error_message.append("すでにその掲示板は存在します")
        else:
            room=models.Room.objects.create(
            name=name
            )
            room.save()
            message.append("掲示板"+name+"を作成しました")

    options = {
        'error_message':error_message,
        'message':message
        }
    return render(request, template_file, options)

def roomView(request,id=None):  

    template_file="mychat/room.html"
    room=None
    if id is not None:
        room = models.Room.objects.get(id=id)
    else:
        room = None

    if room is not None:
        options = {
            'room':room
        }        
    else:
        options = {
        }       

    return render(request,template_file,options)

def searchView(request):
    query = request.GET.get('q', '')
    if query:
        roomlist = models.Room.objects.filter(name__icontains=query)  # 検索キーワードが含まれている掲示板を取得
    else:
        roomlist = models.Room.objects.all()  # 検索クエリがない場合はすべての掲示板を表示
    options={
        'roomlist': roomlist
    }
    return render(request, 'mychat/search.html', options)

class IndexView(View):
    def get(self, request, id=None, *args, **kwargs):
        # 投稿のクエリセットを取得
        queryset = models.Posts.objects.all().order_by('-created_at')

        # ルームの取得
        try:
            room = models.Room.objects.get(id=id)  # URLのidで部屋を取得
        except models.Room.DoesNotExist:
            room = None  # 部屋が存在しない場合は None

        # コンテキストの準備
        options = {
            'posts': queryset,
        }
        
        # roomが存在すれば、optionsに追加
        if room:
            options['room'] = room

        # テンプレートをレンダリング
        return render(request, 'mychat/index.html', options)
    def post(self, request,id, *args, **kwargs):
        # POSTリクエストを処理（フォームの送信やデータ処理を行いたい場合はこちら）
        # 例えばフォームの送信処理など
        return self.get(request, id,*args, **kwargs)
# Make the view accessible

class WriteView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'mychat/write.html', {'form': WriteForm})
    def post(self, request, *args, **kwargs):
        # formに書いた内容を格納する
        form = WriteForm(request.POST)
        # 保存する前に一旦取り出す
        post = form.save(commit=False)
        room_id = 1  
        # 保存
        post.save()
        # indexのviewに移動
        return redirect(reverse('mychat:index',kwargs={'id':room_id}))
write = WriteView.as_view()
