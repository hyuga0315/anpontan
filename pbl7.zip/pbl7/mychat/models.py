from django.db import models
from django.utils import timezone

class User (models.Model):
    name = models.CharField(max_length=20, null=False, blank=False)
    password = models.CharField(max_length=20, null=False, blank=False)
    group_id = models.CharField(max_length=10,null=True)
    islogin = models.BooleanField(default=False) 
class Room(models.Model):
    name = models.TextField(null=False, blank=False)
class Posts(models.Model):
    #Metaとかobjectとかはおまじない
    class Meta(object):
        #作成されるテーブル名を指定
        db_table = 'posts'

    #カラム名=データの形式(管理画面に表示される名前,その他の制約)
    text = models.CharField(verbose_name='本文', max_length=255)
    created_at = models.DateField(verbose_name='作成日', default=timezone.now)

    #管理画面に表示されるように設定(おまじない)
    def __str__(self):
        return self.text, self.created_at
